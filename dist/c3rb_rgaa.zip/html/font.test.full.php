<div class="container">
  <div class="row">
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#myModal">Voir les fonts disponible avec Fontawesome</button>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Modal title</h4>
          </div>
          <div class="modal-body">
              <iframe src="http://fortawesome.github.io/Font-Awesome/icons/" frameborder="0" width="100%" height="250" scrolling="auto">If you can see this, your browser does not support iFrames</iframe>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>
